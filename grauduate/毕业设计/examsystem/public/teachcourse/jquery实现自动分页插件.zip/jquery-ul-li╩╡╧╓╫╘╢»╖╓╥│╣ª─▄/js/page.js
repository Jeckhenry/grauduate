 void function () {
 	var serverList = window.serverList = {
 		setTab:function( opt ){
 			opt = $.extend({
 				parent:$('#serverTab'), //选项卡父级
 				format:"<li>{tab}</li>", //选项卡模板(不能嵌套同种标签)
 				current:"on", //切换类
 				event:'click', //切换事件
 				target:$('#listContent li'), //切换目标
 				hotText:false, //第一个显示卡是否显示“推荐服务器”
 				num:30, //每选项卡数目
 				specials:[]
 			}, opt);

 			var tabTagName,
 				tabs = [],
 				html = "",
 				length,
 				target = opt.target;

			try{
				tabTagName = opt.format.match(/^<(\w+)/)[1];
			}catch(e){
				return alert('选项卡模板错误,找不到匹配的标签名')
			}			
			for (var i = 0, tmpArr = [], tmpHtml = ''; i < opt.specials.length; i++) {
				var tmp = $();
				target = target.filter(function(index) {
					if (this.getAttribute('data-special') == opt.specials[i].attr) {
						tmp = tmp.add(this);
						return false;
					}
					return true;
				});
			}			
			length = target.length;
 			for(var i = 0, j = 0; j < length; i = j){
 				j += opt.num;
 				j = j > length ? length : j;
 				if( i === 0 && opt.hotText ){
 					html += opt.format.replace(/{tab}/, opt.hotText)
 				}else{
 					html +=  opt.format.replace(/{tab}/, (length-j+1)+'-'+(length-i));
 				}
 				tabs.push(target.slice(i, j));
 			}
 			tabs = tabs.concat(tmpArr);
 			html += tmpHtml;

 			if(!tabs.length){
 				return this;
 			}

 			opt.parent.html(html);

 			var tabElements = opt.parent.find( tabTagName );

 			function show( index ){
 				opt.target.hide();
 				tabs[index].show();
 				$(tabElements[index]).addClass( opt.current ).siblings().removeClass( opt.current );
 			}

 			opt.parent.on(opt.event, tabTagName , function(){
 				var index = tabElements.index( this );
 				show(index);
 			});
 			show(0);
 			return this;
 		}
 	
 	}

 }();